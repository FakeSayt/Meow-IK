<?php
declare(strict_types=1);
function hahMailEscape($value):string{return htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8');}
function hahShopUrl():string{
 $url=function_exists('val')?(string)val('shop_url','https://autobothub.pl/hahoutlet/index.php'):'https://autobothub.pl/hahoutlet/index.php';
 return filter_var($url,FILTER_VALIDATE_URL)&&str_starts_with($url,'https://')?$url:'https://autobothub.pl/hahoutlet/index.php';
}
function hahMailLayout(string $heading,string $content):string{
 return '<!doctype html><html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.hahMailEscape($heading).'</title></head><body style="margin:0;background:#f5eee8;padding:24px 12px;font-family:Arial,sans-serif;color:#403333"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:620px;background:#fffaf5;border:1px solid #e6d6cc;border-radius:18px"><tr><td style="padding:30px;background:#763e49;color:#fff;text-align:center;font-size:22px;letter-spacing:3px">KOLO HAH OUTLET</td></tr><tr><td style="padding:30px"><h1 style="font-family:Georgia,serif;font-size:28px;color:#763e49;margin:0 0 22px">'.hahMailEscape($heading).'</h1>'.$content.'</td></tr><tr><td style="padding:20px 30px;border-top:1px solid #e6d6cc;font-size:12px;line-height:1.7;color:#786763">Dziękujemy, że wybierasz HAH Outlet.<br><a href="'.hahMailEscape(hahShopUrl()).'" style="color:#763e49">Odwiedź nasz sklep</a></td></tr></table></td></tr></table></body></html>';
}
function hahMailButton(string $url,string $text):string{return '<p style="margin:26px 0"><a href="'.hahMailEscape($url).'" style="display:inline-block;background:#763e49;color:#fff;text-decoration:none;padding:14px 22px;border-radius:7px;font-weight:bold">'.hahMailEscape($text).'</a></p>';}
function hahMailItems(array $items):string{
 $html='<table width="100%" cellpadding="12" cellspacing="0" style="border-collapse:collapse;font-size:14px"><tr style="background:#f1e5de"><th align="left">Produkt</th><th align="right">Cena</th></tr>';
 foreach($items as $p)$html.='<tr><td style="border-bottom:1px solid #eaded5">'.hahMailEscape($p['name']).'<br><span style="color:#786763">Rozmiar: '.hahMailEscape($p['size']??'').'</span></td><td align="right" style="border-bottom:1px solid #eaded5;white-space:nowrap">'.number_format((float)$p['price'],2,',',' ').' zł</td></tr>';
 return $html.'</table>';
}
function hahOrderMailHtml(array $order,array $config):string{
 $ref=hahMailEscape($order['order_ref']);$items=$order['items'];
 $body='<p style="line-height:1.7">Dziękujemy za zamówienie! Przygotujemy je po potwierdzeniu wpłaty.</p><p><strong>Numer zamówienia: '.$ref.'</strong></p>'.hahMailItems($items);
 $body.='<p>Dostawa: '.number_format((float)$order['shipping_price'],2,',',' ').' zł</p><p style="font-size:22px;color:#763e49"><strong>Do zapłaty: '.number_format((float)$order['total'],2,',',' ').' zł</strong></p><div style="padding:20px;background:#f1e5de;border-radius:10px;line-height:1.9"><strong>Dane do przelewu</strong><br>Odbiorca: '.hahMailEscape($config['recipient']).'<br>Bank: '.hahMailEscape($config['bank_name']).'<br>Rachunek: <span style="word-break:break-all">'.hahMailEscape($config['bank_account']).'</span><br>Tytuł przelewu: <strong>'.$ref.'</strong></div><p>Rezerwacja do: '.date('d.m.Y H:i',(int)$order['expires_at']).'</p><p style="line-height:1.7">W tytule przelewu podaj dokładnie numer zamówienia. Nie trzeba wpisywać adresu.</p>'.hahMailButton(hahShopUrl(),'Przejdź do sklepu');
 $body.='<div style="font-size:12px;line-height:1.8;color:#786763"><strong>Sprzedawca</strong><br>'.hahMailEscape($config['seller_name']).'<br>'.hahMailEscape($config['seller_address']).'<br>NIP: '.hahMailEscape($config['seller_nip']).' · REGON: '.hahMailEscape($config['seller_regon']).'<br>Kontakt: '.hahMailEscape($config['shop_email']).'<p>To potwierdzenie złożenia zamówienia, nie potwierdzenie zapłaty ani dokument fiskalny.</p><strong>Warunki zakupu</strong><p>Towar i cena: zgodnie z powyższym podsumowaniem. Płatność przelewem, wysyłka po potwierdzeniu wpłaty. Konsumentowi co do zasady przysługuje 14 dni na odstąpienie od otrzymania towaru. Reklamacje zgłaszaj na e-mail sprzedawcy. Wzór odstąpienia i szczegółowe warunki: w regulaminie udostępnionym przed zakupem.</p></div>';
 return hahMailLayout('Twoje zamówienie jest przyjęte',$body);
}
function hahTrackingUrl(string $number):string{return 'https://www.epaka.pl/sledzenie-przesylek/'.rawurlencode(trim($number));}
function hahShipmentMailHtml(array $order,array $config):string{
 $items=json_decode($order['items_json'],true)?:[];
 $body='<p style="line-height:1.7">Dobra wiadomość — Twoje zamówienie zostało wysłane!</p><p><strong>Numer zamówienia: '.hahMailEscape($order['order_ref']).'</strong></p><div style="background:#f1e5de;padding:20px;border-radius:10px;line-height:1.9">Przewoźnik: <strong>'.hahMailEscape($order['shipping_carrier']).'</strong><br>Numer przesyłki: <strong style="word-break:break-all">'.hahMailEscape($order['tracking_number']).'</strong><br>Wysłano: '.date('d.m.Y H:i',(int)$order['shipped_at']).'</div>'.hahMailButton(hahTrackingUrl((string)$order['tracking_number']),'Śledź przesyłkę w ePaka').'<p style="font-size:13px;line-height:1.7">Przycisk otworzy śledzenie Twojej przesyłki. Status u przewoźnika może pojawić się po pierwszym skanowaniu.</p>'.hahMailItems($items).'<p><strong>Wartość zamówienia: '.number_format((float)$order['total'],2,',',' ').' zł</strong></p><p>Masz pytania? Napisz do nas: '.hahMailEscape($config['shop_email']).'.</p>';
 return hahMailLayout('Twoja paczka jest w drodze',$body);
}
function hahSendMail(string $to,string $subject,string $html,string $plain):bool{
 global $config;$boundary='hah_'.bin2hex(random_bytes(16));
 $headers=['From: '.$config['from_email'],'MIME-Version: 1.0','Content-Type: multipart/alternative; boundary="'.$boundary.'"'];
 $body='--'.$boundary."\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($plain),76,"\r\n").'--'.$boundary."\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($html),76,"\r\n").'--'.$boundary."--\r\n";
 return @mail($to,'=?UTF-8?B?'.base64_encode($subject).'?=',$body,implode("\r\n",$headers));
}

function hahPaymentMailHtml(array $order,array $config):string{
 $body='<p style="line-height:1.7">Potwierdzamy otrzymanie wpłaty za Twoje zamówienie. Dziękujemy! Teraz przygotujemy Twoje zakupy do wysyłki.</p><div style="padding:20px;background:#f1e5de;border-radius:10px;line-height:1.9">Numer zamówienia: <strong>'.hahMailEscape($order['order_ref']).'</strong><br>Potwierdzona kwota: <strong>'.number_format((float)$order['total'],2,',',' ').' zł</strong><br>Potwierdzenie wpłaty: '.(!empty($order['paid_at'])?date('d.m.Y H:i',(int)$order['paid_at']):'Potwierdzono w panelu sklepu').'</div>'.hahMailItems(json_decode($order['items_json'],true)?:[]).'<p style="line-height:1.7">Po wysłaniu paczki otrzymasz osobną wiadomość z numerem przesyłki i linkiem do śledzenia.</p>'.hahMailButton(hahShopUrl(),'Odwiedź sklep').'<p style="font-size:12px;line-height:1.7;color:#786763">Wiadomość potwierdza odnotowanie wpłaty przez sklep i nie stanowi dokumentu fiskalnego.<br>Kontakt: '.hahMailEscape($config['shop_email']).'</p>';
 return hahMailLayout('Wpłata potwierdzona — dziękujemy!',$body);
}
