<?php
declare(strict_types=1);
require_once __DIR__.'/mail_templates.php';
function hahSendShipment(array $order):string{
 global $db,$config;$attempt=bin2hex(random_bytes(16));
 $claim=$db->prepare("UPDATE orders SET shipment_mail_state='sending',shipment_mail_attempted_at=?,shipment_mail_attempt_token=? WHERE order_ref=? AND status='shipped' AND (shipment_mail_state IN ('pending','failed') OR (shipment_mail_state='sending' AND shipment_mail_attempted_at<?))");
 $claim->execute([time(),$attempt,$order['order_ref'],time()-300]);
 if($claim->rowCount()!==1)return 'Przesyłka jest wysłana. Wiadomość została już przekazana do poczty albo jest właśnie wysyłana.';
 $plain='Zamówienie '.$order['order_ref']." zostało wysłane.\nPrzewoźnik: ".$order['shipping_carrier']."\nNumer przesyłki: ".$order['tracking_number']."\nŚledzenie: ".hahTrackingUrl((string)$order['tracking_number'])."\nKontakt: ".$config['shop_email'];
 try{$ok=hahSendMail($order['customer_email'],'Twoja przesyłka została wysłana — '.$order['order_ref'],hahShipmentMailHtml($order,$config),$plain);}catch(Throwable $e){error_log('[HAH shipment] '.get_class($e));$ok=false;}
 $finish=$db->prepare("UPDATE orders SET shipment_mail_state=?,shipment_mail_sent_at=? WHERE order_ref=? AND shipment_mail_state='sending' AND shipment_mail_attempt_token=?");$finish->execute([$ok?'sent':'failed',$ok?time():null,$order['order_ref'],$attempt]);
 if($finish->rowCount()!==1)return 'Stan wiadomości zmienił się w innej sesji. Sprawdź status e-maila w tabeli zamówień.';
 return $ok?'Przesyłka oznaczona jako wysłana. Wiadomość przekazano do poczty; nie jest to potwierdzenie doręczenia.':'Przesyłka oznaczona jako wysłana, ale hosting odrzucił e-mail. Użyj przycisku „Ponów e-mail”.';
}
function hahFulfillOrder(string $action,array $post):string{
 global $db;
 $ref=(string)($post['ref']??'');$db->beginTransaction();
 try{
  $q=$db->prepare('SELECT * FROM orders WHERE order_ref=? FOR UPDATE');$q->execute([$ref]);$order=$q->fetch();
  if(!$order)throw new RuntimeException('Nie znaleziono zamówienia.');
  if($action==='order_pack'){
   if($order['status']==='packing'){$db->commit();return 'Zamówienie jest już kompletowane.';}
   if($order['status']!=='paid')throw new RuntimeException('Kompletowanie jest dostępne po potwierdzeniu wpłaty.');
   $db->prepare("UPDATE orders SET status='packing',packing_at=? WHERE order_ref=?")->execute([time(),$ref]);$db->commit();return 'Zamówienie: Kompletowanie.';
  }
  if($action==='order_ship'){
   if($order['status']==='shipped'){$db->commit();return 'Zamówienie zostało już oznaczone jako wysłane. Sprawdź status wiadomości w tabeli.';}
   if($order['status']!=='packing')throw new RuntimeException('Najpierw potwierdź wpłatę i rozpocznij kompletowanie.');
   $email=trim((string)($post['customer_email']??''));$carrier=trim((string)($post['shipping_carrier']??''));$number=trim((string)($post['tracking_number']??''));
   if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>190)throw new RuntimeException('Podaj poprawny e-mail odbiorcy.');
   if(mb_strlen($carrier)<2||mb_strlen($carrier)>80||!preg_match('/^[\p{L}\p{N} ._-]+$/u',$carrier))throw new RuntimeException('Podaj nazwę przewoźnika (2–80 znaków).');
   if(!preg_match('/^[A-Za-z0-9][A-Za-z0-9 .\/_-]{2,119}$/D',$number))throw new RuntimeException('Podaj numer przesyłki (3–120 znaków).');
   $now=time();$db->prepare("UPDATE orders SET status='shipped',customer_email=?,shipping_carrier=?,tracking_number=?,shipped_at=?,shipment_mail_state='pending' WHERE order_ref=?")->execute([$email,$carrier,$number,$now,$ref]);
   $order=array_merge($order,['customer_email'=>$email,'shipping_carrier'=>$carrier,'tracking_number'=>$number,'shipped_at'=>$now,'status'=>'shipped']);
  }elseif($action==='order_mail_retry'){
   if($order['status']!=='shipped'||!filter_var($order['customer_email'],FILTER_VALIDATE_EMAIL))throw new RuntimeException('Brak wysłanej przesyłki lub adresu odbiorcy.');
  }else throw new RuntimeException('Nieznany etap zamówienia.');
  $db->commit();return hahSendShipment($order);
 }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
}
function hahOrderActions(array $order):string{
 $base='<input type="hidden" name="csrf" value="'.hahMailEscape(csrf()).'"><input type="hidden" name="ref" value="'.hahMailEscape($order['order_ref']).'">';
 if($order['status']==='paid')return '<form method="post">'.$base.'<input type="hidden" name="action" value="order_pack"><button class="btn small">Kompletuj zamówienie</button></form>';
 if($order['status']==='packing')return '<form method="post" class="shipment-form">'.$base.'<input type="hidden" name="action" value="order_ship"><label>E-mail odbiorcy<input type="email" name="customer_email" value="'.hahMailEscape($order['customer_email']??'').'" maxlength="190" required></label><label>Przewoźnik<input name="shipping_carrier" placeholder="np. InPost, DPD, DHL" maxlength="80" required></label><label>Numer przesyłki<input name="tracking_number" maxlength="120" required></label><button class="btn small primary">Oznacz jako wysłane i wyślij e-mail</button></form>';
 if($order['status']==='shipped'){
  $html='<div class="shipment-info"><strong>'.hahMailEscape($order['shipping_carrier']).'</strong><br>Numer: '.hahMailEscape($order['tracking_number']).'<br><a href="'.hahMailEscape(hahTrackingUrl((string)$order['tracking_number'])).'" target="_blank" rel="noopener">Śledź przesyłkę</a><br>';
  $state=$order['shipment_mail_state'];$html.=$state==='sent'?'E-mail przekazany do poczty.':($state==='sending'?'Trwa wysyłanie e-maila.':'E-mail oczekuje lub nie został wysłany.');
  if($state!=='sent')$html.='<form method="post">'.$base.'<input type="hidden" name="action" value="order_mail_retry"><button class="btn small">Ponów e-mail</button></form>';
  return $html.'</div>';
 }
 return '';
}
