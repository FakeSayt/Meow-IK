(() => {
  const form=document.getElementById('productForm');if(!form)return;
  const photos=document.getElementById('hahPhotos'),video=document.getElementById('hahVideo');
  const progress=document.getElementById('hahUploadProgress'),tokens=document.getElementById('hahMediaTokens');
  const gallery=document.getElementById('existingPhotos'),mode=document.getElementById('mediaUploadMode');
  const csrf=form.querySelector('input[name="csrf"]').value;
  const MAX=80*1024*1024,CHUNK=4*1024;
  function operation(){return [...crypto.getRandomValues(new Uint8Array(16))].map(byte=>byte.toString(16).padStart(2,'0')).join('');}
  let entries=[],originalPhotos=[],busy=false,sequence=0,videoReady=null,saveOperation=operation();
  function message(text,error=false){progress.textContent=text;progress.className=error?'media-progress is-error':'media-progress';}
  function revoke(entry){if(entry.file&&entry.preview)URL.revokeObjectURL(entry.preview);}
  function accepted(file){return ['image/jpeg','image/png','image/webp','image/avif'].includes(file.type)||/\.(jpe?g|png|webp|avif)$/i.test(file.name);}
  function makeEntry(file){return {key:'new:'+(++sequence),file,name:file.name,preview:URL.createObjectURL(file),ready:null};}
  function canEdit(){if(busy){message('Poczekaj na zakończenie przesyłania.');return false;}return true;}
  function hidden(name,value){const input=document.createElement('input');input.type='hidden';input.name=name;input.value=value;tokens.append(input);}
  function syncTokens(){
    tokens.replaceChildren();hidden('gallery_managed','1');hidden('save_operation',saveOperation);
    const kept=entries.filter(entry=>!entry.file).map(entry=>entry.url);
    originalPhotos.filter(url=>!kept.includes(url)).forEach(url=>hidden('remove_images[]',url));
    for(const entry of entries){
      if(entry.file){if(entry.ready){hidden('uploaded_photos[]',entry.ready.id);hidden('image_order[]','upload:'+entry.ready.id);}}
      else hidden('image_order[]','existing:'+entry.url);
    }
    if(videoReady)hidden('uploaded_video',videoReady.id);
  }
  function button(label,action,disabled=false){const b=document.createElement('button');b.type='button';b.className='btn small';b.textContent=label;b.disabled=disabled||busy;b.addEventListener('click',action);return b;}
  function render(focusKey=null,focusLabel=''){
    gallery.replaceChildren();syncTokens();
    if(!entries.length){const note=document.createElement('p');note.className='muted';note.textContent='Nie dodano zdjęć. Wybierz zdjęcia powyżej; podgląd pojawi się tutaj.';gallery.append(note);if(focusKey!==null)photos.focus();return;}
    entries.forEach((entry,index)=>{
      const card=document.createElement('article');card.className='media-card';
      const img=document.createElement('img');img.dataset.mediaKey=entry.key;img.alt='Zdjęcie produktu '+(index+1);
      img.onerror=()=>{
        if(!entry.file||entry.previewFallback)return;
        entry.previewFallback=true;const reader=new FileReader();
        reader.onload=()=>{URL.revokeObjectURL(entry.preview);entry.preview=String(reader.result);gallery.querySelectorAll('img').forEach(current=>{if(current.dataset.mediaKey===entry.key)current.src=entry.preview;});};
        reader.readAsDataURL(entry.file);
      };
      img.src=entry.preview||entry.url;card.append(img);
      const label=document.createElement('strong');label.textContent=index===0?'Zdjęcie główne':'Zdjęcie '+(index+1);card.append(label);
      const name=document.createElement('small');name.textContent=entry.name||'Zapisane zdjęcie';card.append(name);
      const controls=document.createElement('div');controls.className='media-card-actions';
      controls.append(button('Ustaw jako główne',()=>{entries.splice(index,1);entries.unshift(entry);render(entry.key,'Ustaw jako główne');},index===0));
      controls.append(button('Przesuń wcześniej',()=>{[entries[index-1],entries[index]]=[entries[index],entries[index-1]];render(entry.key,'Przesuń wcześniej');},index===0));
      controls.append(button('Przesuń później',()=>{[entries[index+1],entries[index]]=[entries[index],entries[index+1]];render(entry.key,'Przesuń później');},index===entries.length-1));
      const replacement=document.createElement('input');replacement.type='file';replacement.accept='image/jpeg,image/png,image/webp,image/avif';replacement.hidden=true;replacement.disabled=busy;
      replacement.addEventListener('change',()=>{const file=replacement.files[0];if(!file)return;if(!accepted(file)||file.size<1||file.size>MAX){message('Wybierz zdjęcie JPG, PNG, WebP lub AVIF do 80 MB.',true);return;}revoke(entry);entries[index]=makeEntry(file);render(entries[index].key,'Zastąp zdjęcie');});
      controls.append(button('Zastąp zdjęcie',()=>replacement.click()));controls.append(replacement);
      controls.append(button('Usuń zdjęcie',()=>{revoke(entry);entries.splice(index,1);render((entries[index]||entries[index-1])?.key||'empty','Usuń zdjęcie');}));
      card.append(controls);gallery.append(card);
      if(entry.key===focusKey){const enabled=[...controls.querySelectorAll('button')].filter(b=>!b.disabled);(enabled.find(b=>b.textContent===focusLabel)||enabled[0])?.focus();}
    });
  }
  photos.addEventListener('change',()=>{
    if(!canEdit())return;
    const files=[...photos.files];
    if(files.some(file=>!accepted(file)||file.size<1||file.size>MAX)){message('Wybierz prawidłowe zdjęcia JPG, PNG, WebP lub AVIF do 80 MB.',true);photos.value='';return;}
    if(entries.length+files.length>100){message('Możesz dodać maksymalnie 100 zdjęć produktu.',true);photos.value='';return;}
    files.forEach(file=>entries.push(makeEntry(file)));photos.value='';render();
  });
  video.addEventListener('change',()=>{videoReady=null;syncTokens();});
  function loadProduct(product){
    if(!canEdit())return;
    saveOperation=operation();
    entries.forEach(revoke);let images=[];
    try{images=JSON.parse(product.images_json||'[]');}catch(_){}
    originalPhotos=Array.isArray(images)?[...new Set(images.filter(url=>typeof url==='string'))]:[];
    entries=originalPhotos.map(url=>({key:'existing:'+url,url}));videoReady=null;photos.value='';video.value='';message('');render();
    const holder=document.getElementById('existingVideo');holder.replaceChildren();
    if(product.video_url){
      const label=document.createElement('label');label.className='checkbox-label';
      const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.name='remove_video';checkbox.value='1';label.append(checkbox,document.createTextNode(' Usuń obecny film'));holder.append(label);
      try{const url=new URL(product.video_url,location.href);if(['http:','https:'].includes(url.protocol)){const link=document.createElement('a');link.href=url.href;link.target='_blank';link.rel='noopener';link.textContent='Zobacz obecny film';holder.append(link);}}catch(_){}
    }
  }
  form.addEventListener('reset',event=>{
    if(busy){event.preventDefault();return;}
    entries.forEach(revoke);entries=[];originalPhotos=[];videoReady=null;saveOperation=operation();message('');render();
    document.getElementById('existingVideo').replaceChildren();
    document.getElementById('productId').value='0';document.getElementById('formTitle').textContent='Dodaj nowy produkt';
    document.getElementById('pMaterialCustomRow').hidden=true;
    document.getElementById('pMaterialCustom').required=false;
  });
  async function request(action,fields={},query='',multipart=false){
    const controller=new AbortController(),timeout=setTimeout(()=>controller.abort(),multipart?120000:45000);
    try{
      const body=multipart?fields:new URLSearchParams(fields);
      const response=await fetch('admin-media-upload.php?action='+action+query,{method:'POST',credentials:'same-origin',headers:{'X-CSRF-Token':csrf},body,signal:controller.signal});
      const json=await response.json().catch(()=>({error:'Hosting odrzucił przesyłanie. Spróbuj trybu zgodnego z hostingiem.'}));
      if(!response.ok||json.error){const error=new Error(json.error||'Błąd przesyłania.');error.status=response.status;throw error;}
      return json;
    }finally{clearTimeout(timeout);}
  }
  async function encode(blob){const bytes=new Uint8Array(await blob.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(binary);}
  async function encodeHex(blob){return [...new Uint8Array(await blob.arrayBuffer())].map(byte=>byte.toString(16).padStart(2,'0')).join('');}
  async function retry(action,fields,query){
    for(let attempt=0;attempt<3;attempt++){
      try{return await request(action,fields,query);}catch(error){if(attempt===2||error.status&&error.status<500&&error.status!==429)throw error;}
    }
  }
  async function transfer(file,kind,done,total){
    if(mode.value==='direct'){
      const body=new FormData();body.append('kind',kind);body.append('file',file,file.name);
      try{return await request('direct',body,'',true);}catch(error){if(error.status===403)throw error;message('Zwykłe przesyłanie nie powiodło się. Używam trybu zgodnego z hostingiem…');}
    }
    const {ids,transport}=await request('init',{files:JSON.stringify([{size:file.size,kind}])});const id=ids[0];
    for(let offset=0;offset<file.size;offset+=CHUNK){
      const part=file.slice(offset,Math.min(file.size,offset+CHUNK));
      const fields=transport==='hex'?{offset:String(offset),length:String(part.size),part:await encodeHex(part)}:{offset:String(offset),data:await encode(part)};
      const result=await retry(transport==='hex'?'chunk_hex':'chunk_form',fields,'&id='+encodeURIComponent(id));
      if(result.received!==offset+part.size)throw new Error('Hosting nie przyjął całej części zdjęcia. Ponów zapis produktu.');
      message(`Przesyłanie: ${Math.min(100,Math.round((done+offset+part.size)/total*100))}% · ${file.name}`);
    }
    return retry('finish',{},'&id='+encodeURIComponent(id));
  }
  function setBusy(value){
    busy=value;photos.disabled=value;video.disabled=value;mode.disabled=value;
    form.querySelector('button[type="submit"]').disabled=value;
    form.querySelector('button[type="reset"]').disabled=value;render();
  }
  form.addEventListener('submit',async event=>{
    event.preventDefault();if(busy||!form.reportValidity())return;
    const pending=entries.filter(entry=>entry.file&&!entry.ready);
    const movie=video.files[0];const pendingMovie=movie&&!videoReady?movie:null;
    const total=pending.reduce((sum,entry)=>sum+entry.file.size,0)+(pendingMovie?.size||0);
    if(total>MAX){message(`Wybrane pliki przekraczają limit 80 MB. Usuń część zdjęć lub wybierz mniejsze pliki.`,true);return;}
    setBusy(true);message(total?'Rozpoczynam przesyłanie…':'Zapisuję produkt…');
    try{
      let done=0;
      for(const entry of pending){entry.ready=await transfer(entry.file,'photo',done,total);done+=entry.file.size;syncTokens();}
      if(pendingMovie){videoReady=await transfer(pendingMovie,'video',done,total);syncTokens();}
      syncTokens();message('Zdjęcia gotowe. Zapisuję produkt…');
      const response=await fetch(form.getAttribute('action')||location.href,{method:'POST',credentials:'same-origin',headers:{'X-HAH-Request':'product-save'},body:new FormData(form)});
      const result=await response.json().catch(()=>({error:'Hosting odrzucił zapis produktu.'}));
      if(!response.ok||!result.ok){const error=new Error(result.error||'Nie udało się zapisać produktu.');error.status=response.status;throw error;}
      // A different query also forces a GET when the Products tab already has this hash.
      location.assign('admin.php?saved='+Date.now()+'#lista-produktow');
    }catch(error){setBusy(false);const retryHint=[403,409].includes(error.status)?'':' Zdjęcia i formularz pozostają wybrane. Kliknij ponownie „Zapisz produkt”.';message('Błąd: '+(error.name==='AbortError'?'Przesyłanie trwało zbyt długo.':error.message)+retryHint,true);}
  });
  window.HahMedia={loadProduct,canEdit};render();
})();
