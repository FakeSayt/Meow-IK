/* Progressive enhancement: every form remains a standard PHP form. */
document.addEventListener('DOMContentLoaded', () => {
  const nav = document.querySelector('.admin-shortcuts');
  if (!nav) return;
  const groups = {
    overview: ['overview-admin','dashboard-actions'],
    products: ['produkty-admin','lista-produktow'],
    orders: ['zamowienia-admin'],
    live: ['live-admin','powiadomienia-live','live-lista'],
    marketing: ['promocje','vouchery'],
    settings: ['ustawienia-admin','category-management','bezpieczenstwo-mysql','account-settings','admin-logs']
  };
  const tabs = [...nav.querySelectorAll('[data-admin-tab]')];
  function sectionForHash() {
    let id;
    try { id = decodeURIComponent(location.hash.slice(1)); } catch (_) { return 'overview'; }
    if (id === 'kategorie') return 'settings';
    if (id === 'formTitle') return 'products';
    return Object.keys(groups).find(group => groups[group].includes(id)) || 'overview';
  }
  function activate(group) {
    for (const [name,ids] of Object.entries(groups)) {
      ids.forEach(id => { const section=document.getElementById(id); if(section) section.hidden=name !== group; });
    }
    tabs.forEach(tab => {
      const active=tab.dataset.adminTab===group;
      tab.classList.toggle('is-active',active);
      active ? tab.setAttribute('aria-current','page') : tab.removeAttribute('aria-current');
    });
  }
  tabs.forEach(tab => tab.addEventListener('click',() => activate(tab.dataset.adminTab)));
  document.querySelectorAll('[data-admin-link]').forEach(link => link.addEventListener('click',() => activate(link.dataset.adminLink)));
  window.addEventListener('hashchange',() => activate(sectionForHash()));
  activate(sectionForHash());

  const normalize=value=>String(value||'').toLocaleLowerCase('pl-PL').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/ł/g,'l').trim();
  function filterRows(tableId, searchId, selectId, countId, emptyId, predicate) {
    const table=document.getElementById(tableId), search=document.getElementById(searchId), select=document.getElementById(selectId);
    function update() {
      const query=normalize(search.value), filter=select.value;
      let count=0;
      table.querySelectorAll('tbody tr').forEach(row => {
        const visible=normalize(row.dataset.search || row.textContent).includes(query) && predicate(row,filter);
        row.hidden=!visible;
        if(visible)count++;
      });
      document.getElementById(countId).textContent=`Wyniki: ${count}`;
      document.getElementById(emptyId).hidden=count>0;
    }
    search.addEventListener('input',update);select.addEventListener('change',update);update();
    return update;
  }
  const updateProducts=filterRows('lista-produktow','adminProductSearch','adminStockFilter','adminProductCount','adminProductEmpty',(row,filter) => {
    const active=row.dataset.active==='1', stock=Number(row.dataset.stock);
    return !filter || filter==='active'&&active || filter==='hidden'&&!active || filter==='low'&&active&&stock<=2 || filter==='sold'&&active&&stock===0;
  });
  filterRows('zamowienia-admin','adminOrderSearch','adminOrderStatus','adminOrderCount','adminOrderEmpty',(row,filter) => !filter || (filter==='pending' ? ['pending','mail_failed'].includes(row.dataset.status) : row.dataset.status===filter));
  document.querySelectorAll('[data-low-stock]').forEach(link => link.addEventListener('click',() => {
    activate('products');document.getElementById('adminProductSearch').value='';document.getElementById('adminStockFilter').value='low';updateProducts();
  }));
});
