/* Small client-side enhancements. Favorites stay in this browser only. */
window.HahShop = (() => {
  const storageKey = 'hah-outlet-favorites-v1';
  let favorites = new Set(), favoritesOnly = false;
  function decode(value) {
    const stored = JSON.parse(value || '[]');
    return new Set(Array.isArray(stored) ? stored.filter(id => Number.isSafeInteger(id) && id > 0) : []);
  }
  try { favorites = decode(localStorage.getItem(storageKey)); } catch (_) {}
  const sizeOf = product => String(product.size || '').trim().toLocaleUpperCase('pl-PL');
  function toggle(id) {
    const remove = favorites.has(id);
    try { favorites = decode(localStorage.getItem(storageKey)); } catch (_) {}
    remove ? favorites.delete(id) : favorites.add(id);
    try { localStorage.setItem(storageKey, JSON.stringify([...favorites])); } catch (_) {}
  }
  function filter(items) {
    const size = document.getElementById('sizeFilter').value;
    const inStock = document.getElementById('availableFilter').checked;
    return items.filter(p => (!size || sizeOf(p) === size) && (!inStock || Number(p.available) > 0) && (!favoritesOnly || favorites.has(Number(p.id))));
  }
  function refresh(items, count) {
    const select = document.getElementById('sizeFilter'), selected = select.value;
    const sizes = [...new Set(items.map(sizeOf).filter(Boolean))].sort((a,b) => a.localeCompare(b,'pl',{numeric:true}));
    if (JSON.stringify(sizes) !== select.dataset.sizes) {
      select.replaceChildren(new Option('Wszystkie rozmiary',''), ...sizes.map(size => new Option(size,size)));
      select.dataset.sizes = JSON.stringify(sizes);
      if (sizes.includes(selected)) select.value = selected;
    }
    document.getElementById('favoriteCount').textContent = items.filter(p => favorites.has(Number(p.id))).length;
    document.getElementById('favoritesBtn').setAttribute('aria-pressed', String(favoritesOnly));
    document.getElementById('resultsCount').textContent = `${count} ${count === 1 ? 'produkt' : count % 10 >= 2 && count % 10 <= 4 && (count % 100 < 12 || count % 100 > 14) ? 'produkty' : 'produktów'}`;
    document.getElementById('collectionLabel').textContent = favoritesOnly ? 'Twoje ulubione' : 'Nasza kolekcja';
    document.getElementById('emptyMessage').textContent = favoritesOnly ? 'Tutaj czekają Twoje ulubione. Zapisz produkt, klikając serduszko na jego karcie.' : 'Nie znaleziono produktów. Zmień rozmiar, kategorię lub wpisaną frazę.';
  }
  window.addEventListener('storage',event => {
    if(event.key !== storageKey && event.key !== null) return;
    try { favorites = decode(event.newValue); } catch (_) { return; }
    if(typeof renderProducts === 'function') renderProducts();
  });
  document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('favoritesBtn').addEventListener('click', () => {
      favoritesOnly = !favoritesOnly;
      renderProducts();
      document.getElementById('produkty').scrollIntoView({behavior:'smooth'});
    });
    ['sizeFilter','availableFilter'].forEach(id => document.getElementById(id).addEventListener('change',renderProducts));
    function reset() {
      favoritesOnly = false; currentCategory = 0; search = ''; liveResults = []; sort = 'new';
      clearTimeout(lookupTimer);
      document.getElementById('searchInput').value = '';
      document.getElementById('sortSelect').value = 'new';
      document.getElementById('sizeFilter').value = '';
      document.getElementById('availableFilter').checked = false;
      render();
    }
    document.querySelectorAll('[data-reset-filters]').forEach(button => button.addEventListener('click',reset));
    const menu = document.getElementById('menuToggle'), nav = document.getElementById('mainNav');
    function closeMenu() { menu.setAttribute('aria-expanded','false'); nav.classList.remove('is-open'); }
    menu.addEventListener('click', () => {
      const open = menu.getAttribute('aria-expanded') !== 'true';
      menu.setAttribute('aria-expanded',String(open)); nav.classList.toggle('is-open',open);
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click',closeMenu));
    document.addEventListener('keydown',event => { if(event.key === 'Escape') closeMenu(); });
    document.addEventListener('click',event => { if(!event.target.closest('.header')) closeMenu(); });
  });
  return {filter, refresh, toggle, isFavorite: id => favorites.has(Number(id))};
})();
