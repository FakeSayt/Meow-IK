<?php
declare(strict_types=1);
require __DIR__.'/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
function outMedia(array $data,int $status=200):never {
 http_response_code($status);echo json_encode($data,JSON_UNESCAPED_UNICODE);exit;
}
if($_SERVER['REQUEST_METHOD']!=='POST'||empty($_SESSION['admin']))outMedia(['error'=>'Zaloguj się ponownie do panelu.'],403);
$token=(string)($_SERVER['HTTP_X_CSRF_TOKEN']??'');
if(!$token||!hash_equals(csrf(),$token))outMedia(['error'=>'Sesja wygasła. Odśwież panel.'],403);
$action=(string)($_GET['action']??'');
$dir=__DIR__.'/private/upload-parts';
$max=80*1024*1024;$binaryChunk=1024*1024;$formChunk=64*1024;
if(!isset($_SESSION['hah_media_uploads']))$_SESSION['hah_media_uploads']=[];
if(!isset($_SESSION['hah_media_ready']))$_SESSION['hah_media_ready']=[];
function storeMedia(string $path,string $kind,bool $nativeUpload=false,?string $id=null):array {
 $types=$kind==='photo'?['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/avif'=>'avif']:['video/mp4'=>'mp4','video/webm'=>'webm','video/quicktime'=>'mov'];
 $mime=(new finfo(FILEINFO_MIME_TYPE))->file($path);
 if(!isset($types[$mime]))throw new RuntimeException('Niedozwolony format pliku. Zdjęcia: JPG, PNG, WebP lub AVIF.');
 if($kind==='photo'&&!@getimagesize($path))throw new RuntimeException('Plik nie jest prawidłowym zdjęciem.');
 $uploads=__DIR__.'/uploads';
 if(!is_dir($uploads)&&!mkdir($uploads,0755,true)&&!is_dir($uploads))throw new RuntimeException('Nie można utworzyć katalogu zdjęć.');
 if(!is_writable($uploads))throw new RuntimeException('Katalog uploads nie ma uprawnień zapisu.');
 $name=bin2hex(random_bytes(16)).'.'.$types[$mime];$dest=$uploads.'/'.$name;
 $ok=$nativeUpload?move_uploaded_file($path,$dest):rename($path,$dest);
 if(!$ok)throw new RuntimeException('Nie można zapisać pliku docelowego.');
 chmod($dest,0644);$id=$id??bin2hex(random_bytes(16));
 $_SESSION['hah_media_ready'][$id]=['url'=>'uploads/'.$name,'kind'=>$kind,'time'=>time()];
 return ['id'=>$id,'kind'=>$kind,'url'=>'uploads/'.$name];
}
try {
 if($action==='direct'){
  $kind=(string)($_POST['kind']??'');$file=$_FILES['file']??null;
  if(!in_array($kind,['photo','video'],true)||!is_array($file)||is_array($file['error']??null))throw new RuntimeException('Wybierz prawidłowy plik.');
  $error=(int)($file['error']??UPLOAD_ERR_NO_FILE);
  if($error!==UPLOAD_ERR_OK)throw new RuntimeException('Zwykłe przesyłanie jest niedostępne lub plik przekracza limit hostingu. Użyj trybu zgodnego z hostingiem.');
  $size=(int)($file['size']??0);$tmp=(string)($file['tmp_name']??'');
  if($size<1||$size>$max||!is_uploaded_file($tmp))throw new RuntimeException('Niepoprawny plik lub zbyt duży rozmiar.');
  outMedia(storeMedia($tmp,$kind,true));
 }
 if(!is_dir($dir)&&!@mkdir($dir,0700,true)&&!is_dir($dir))throw new RuntimeException('Nie można utworzyć katalogu przesyłania.');
 if(!is_writable($dir))throw new RuntimeException('Katalog private/upload-parts nie ma uprawnień zapisu.');
 if($action==='init'){
  $data=isset($_POST['files'])&&is_string($_POST['files'])?['files'=>json_decode($_POST['files'],true)]:json_decode(file_get_contents('php://input'),true);
  if(!is_array($data)||!isset($data['files'])||!is_array($data['files'])||count($data['files'])<1||count($data['files'])>100)throw new RuntimeException('Niepoprawna lista plików.');
  $total=0;$files=[];$videos=0;
  foreach($data['files'] as $item){
   if(!is_array($item))throw new RuntimeException('Niepoprawna lista plików.');
   $size=(int)($item['size']??0);$kind=(string)($item['kind']??'');
   if($size<1||$size>$max||!in_array($kind,['photo','video'],true))throw new RuntimeException('Niepoprawny plik lub jego rozmiar.');
   if($kind==='video')$videos++;
   $total+=$size;if($total>$max)throw new RuntimeException('Łączny rozmiar plików nie może przekroczyć 80 MB.');
   $files[]=compact('size','kind');
  }
  if($videos>1)throw new RuntimeException('Wybierz maksymalnie jeden film.');
  $batch=bin2hex(random_bytes(16));$response=[];
  foreach($files as $file){
   $id=bin2hex(random_bytes(16));$path=$dir.'/'.$id.'.part';
   $handle=@fopen($path,'x+b');if(!$handle)throw new RuntimeException('Nie można rozpocząć zapisu.');fclose($handle);
   $_SESSION['hah_media_uploads'][$id]=['batch'=>$batch,'size'=>$file['size'],'kind'=>$file['kind'],'received'=>0,'time'=>time()];
   $response[]=$id;
  }
  outMedia(['ids'=>$response]);
 }
 $id=(string)($_GET['id']??'');
 if(!preg_match('/^[a-f0-9]{32}$/',$id))outMedia(['error'=>'Nieznany identyfikator przesyłania.'],403);
 // A repeated finish after a dropped response returns the same saved file.
 if($action==='finish'&&isset($_SESSION['hah_media_ready'][$id])){
  $saved=$_SESSION['hah_media_ready'][$id];outMedia(['id'=>$id,'kind'=>$saved['kind'],'url'=>$saved['url']]);
 }
 if(!isset($_SESSION['hah_media_uploads'][$id]))outMedia(['error'=>'Nieznany identyfikator przesyłania.'],403);
 $meta=&$_SESSION['hah_media_uploads'][$id];$path=$dir.'/'.$id.'.part';
 if(time()-(int)$meta['time']>3600)throw new RuntimeException('Sesja przesyłania wygasła.');
 if($action==='chunk'||$action==='chunk_form'){
  $encoded=$action==='chunk_form';
  $offset=filter_var($encoded?($_POST['offset']??null):($_GET['offset']??null),FILTER_VALIDATE_INT);
  if($encoded){
   $value=$_POST['data']??null;
   if(!is_string($value)||strlen($value)>4*(int)ceil($formChunk/3))throw new RuntimeException('Niepoprawna część pliku.');
   $chunk=base64_decode($value,true);$limit=$formChunk;
  }else{
   $chunk=file_get_contents('php://input',false,null,0,$binaryChunk+1);$limit=$binaryChunk;
  }
  if($chunk===false)throw new RuntimeException('Nie udało się odczytać części pliku.');
  $length=strlen($chunk);
  if(!$encoded&&isset($_SERVER['CONTENT_LENGTH'])&&(int)$_SERVER['CONTENT_LENGTH']!==$length)throw new RuntimeException('Niepełna część pliku. Wybierz tryb zgodny z hostingiem.');
  if($offset===false||$offset<0||$length<1||$length>$limit||$offset+$length>$meta['size'])throw new RuntimeException('Niepoprawna część pliku.');
  if($offset<(int)$meta['received']&&$offset+$length<=(int)$meta['received']){
   $previous=file_get_contents($path,false,null,$offset,$length);
   if($previous!==false&&hash_equals($previous,$chunk))outMedia(['received'=>$meta['received']]);
  }
  if($offset!==(int)$meta['received'])throw new RuntimeException('Niepoprawna kolejność części pliku.');
  $handle=fopen($path,'c+b');if(!$handle)throw new RuntimeException('Nie można zapisać części pliku.');
  try{
   if(!flock($handle,LOCK_EX)||fseek($handle,$offset)!==0)throw new RuntimeException('Nie można zapisać części pliku.');
   $written=0;
   while($written<$length){$n=fwrite($handle,substr($chunk,$written));if($n===false||$n===0){ftruncate($handle,$offset);throw new RuntimeException('Nie można zapisać całej części pliku.');}$written+=$n;}
   if(!fflush($handle)){ftruncate($handle,$offset);throw new RuntimeException('Nie można zakończyć zapisu.');}
  }finally{flock($handle,LOCK_UN);fclose($handle);}
  $meta['received']+=$length;$meta['time']=time();outMedia(['received'=>$meta['received']]);
 }
 if($action==='finish'){
  clearstatcache(true,$path);
  if($meta['received']!==$meta['size']||!is_file($path)||filesize($path)!==$meta['size'])throw new RuntimeException('Plik nie został przesłany w całości.');
  $result=storeMedia($path,$meta['kind'],false,$id);unset($_SESSION['hah_media_uploads'][$id]);outMedia($result);
 }
 throw new RuntimeException('Nieznana akcja.');
}catch(Throwable $error){error_log('[HAH media] '.get_class($error).': '.$error->getMessage());outMedia(['error'=>$error->getMessage()],400);}
