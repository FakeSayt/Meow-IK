<?php
declare(strict_types=1);
// Preferred path: public_html/hahoutlet/private. Previous releases also used public_html/private.
$privateCandidates = [__DIR__.'/private/hahoutlet-config.php', dirname(__DIR__).'/private/hahoutlet-config.php'];
$privateConfig = null;
foreach ($privateCandidates as $candidate) {
    if (is_file($candidate)) { $privateConfig = $candidate; break; }
}
if ($privateConfig === null) {
    http_response_code(503);
    exit('Nie znaleziono konfiguracji. Wgraj folder private do public_html/hahoutlet/private (plik hahoutlet-config.php).');
}
try {
    $config = require $privateConfig;
} catch (Throwable $e) {
    error_log('[HAH config] '.$e->getMessage());
    http_response_code(503);
    exit('Sklep: problem z konfiguracja PHP. Sprawdz log bledow PHP lub plik install-check.php.');
}
if (!is_array($config)) { http_response_code(503); exit('Nieprawidlowa konfiguracja sklepu.'); }
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: SAMEORIGIN');
date_default_timezone_set((string)($config['timezone'] ?? 'Europe/Warsaw'));
// Dedicated PHP session storage for this shop, isolated from other websites on the hosting account.
// Persistent session storage is required for CSRF protection and login.
$sessionDir=__DIR__.'/private/sessions';
if (!is_dir($sessionDir) && !@mkdir($sessionDir,0700,true) && !is_dir($sessionDir)) {
    error_log('[HAH session] Cannot create private/sessions');
    http_response_code(503);
    exit('Nie można utworzyć katalogu sesji. Sprawdź uprawnienia hahoutlet/private/sessions.');
}
if (!is_writable($sessionDir)) {
    error_log('[HAH session] Directory not writable');
    http_response_code(503);
    exit('Katalog sesji nie jest zapisywalny. Sprawdź hahoutlet/private/sessions.');
}
// PHP must be able to write a session before accepting any admin form.
ini_set('session.save_handler','files');
ini_set('session.save_path',$sessionDir);
ini_set('session.use_strict_mode','1');
ini_set('session.use_only_cookies','1');
ini_set('session.cookie_httponly','1');
ini_set('session.cookie_samesite','Lax');
ini_set('session.cache_limiter','nocache');
$https = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off') || (($_SERVER['HTTP_X_FORWARDED_PROTO']??'')==='https'));
// Scope the cookie to this shop so other sites hosted on the same domain do not conflict.
$cookiePath='/hahoutlet';
session_name('HAHOUTLETSESSID');
session_set_cookie_params(['lifetime'=>0,'path'=>$cookiePath,'secure'=>$https,'httponly'=>true,'samesite'=>'Lax']);
if (!session_start()) {
    error_log('[HAH session] session_start failed');
    http_response_code(503);
    exit('Nie udało się uruchomić sesji PHP. Sprawdź ustawienia hostingu.');
}
// Detect real write failures early rather than silently showing misleading CSRF errors.
if (!isset($_SESSION['session_started_at'])) $_SESSION['session_started_at']=time();
// Expire idle administrator sessions after 30 minutes.
if (!empty($_SESSION['admin']) && isset($_SESSION['admin_last_activity']) && time() - (int)$_SESSION['admin_last_activity'] > 1800) {
    unset($_SESSION['admin'], $_SESSION['admin_last_activity']);
    session_regenerate_id(true);
}
if (!empty($_SESSION['admin'])) $_SESSION['admin_last_activity']=time();
header('Cache-Control: no-store, private, max-age=0');
function db():PDO {
 static $pdo=null; if($pdo)return $pdo;
 $host=(string)($GLOBALS['config']['db_host']??'localhost');
 $name=(string)($GLOBALS['config']['db_name']??'');
 $user=(string)($GLOBALS['config']['db_user']??'');
 $password=(string)($GLOBALS['config']['db_password']??'');
 if(!$name||!$user||!$password)throw new RuntimeException('Uzupełnij ustawienia bazy oraz sekret w hahoutlet/private (sprawdz README)');
 $pdo=new PDO('mysql:host='.$host.';dbname='.$name.';charset=utf8mb4',$user,$password,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
 return $pdo;
}
try {
    if (!extension_loaded('pdo_mysql')) {
        throw new RuntimeException('Brak rozszerzenia pdo_mysql w PHP');
    }
    $db = db();
} catch (Throwable $e) {
    error_log('[HAH database connection] '.$e->getMessage());
    http_response_code(503);
    exit('Sklep chwilowo niedostepny: problem z polaczeniem MySQL. Otworz install-check.php i sprawdz konfiguracje.');
}
try {
$db->exec("CREATE TABLE IF NOT EXISTS categories(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,name VARCHAR(190) NOT NULL UNIQUE,sort INT NOT NULL DEFAULT 0) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$db->exec("CREATE TABLE IF NOT EXISTS products(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,category_id BIGINT UNSIGNED NOT NULL,name VARCHAR(255) NOT NULL,description TEXT NOT NULL,price DECIMAL(12,2) NOT NULL,original_price DECIMAL(12,2) NULL,size VARCHAR(100) NOT NULL DEFAULT '',`condition` VARCHAR(150) NOT NULL DEFAULT '',live_code VARCHAR(80) NULL UNIQUE,stock INT NOT NULL DEFAULT 1,active TINYINT NOT NULL DEFAULT 1,created_at BIGINT NOT NULL,images_json TEXT NOT NULL,featured TINYINT NOT NULL DEFAULT 0,material VARCHAR(350) NOT NULL DEFAULT '',video_url VARCHAR(255) NULL, INDEX(category_id),FOREIGN KEY(category_id) REFERENCES categories(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
// Add material composition to an existing installation without removing products.
$materialColumn=$db->query("SHOW COLUMNS FROM products LIKE 'material'")->fetch();
if(!$materialColumn){$db->exec("ALTER TABLE products ADD COLUMN material VARCHAR(350) NOT NULL DEFAULT ''");}
if(!$db->query("SHOW COLUMNS FROM products LIKE 'video_url'")->fetch()){$db->exec("ALTER TABLE products ADD COLUMN video_url VARCHAR(255) NULL");}
$db->exec("CREATE TABLE IF NOT EXISTS reservations(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,product_id BIGINT UNSIGNED NOT NULL,qty INT NOT NULL DEFAULT 1,reservation_token VARCHAR(100) NOT NULL,expires_at BIGINT NOT NULL,order_ref VARCHAR(80) NULL,INDEX idx_product_expiry(product_id,expires_at),INDEX idx_token(reservation_token),INDEX idx_order_ref(order_ref),FOREIGN KEY(product_id) REFERENCES products(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$db->exec("CREATE TABLE IF NOT EXISTS live_subscribers(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,email VARCHAR(190) NOT NULL UNIQUE,status VARCHAR(20) NOT NULL DEFAULT 'pending',token_hash CHAR(64) NOT NULL,requested_at BIGINT NOT NULL,confirmed_at BIGINT NULL,last_sent_event VARCHAR(64) NULL,INDEX(status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$db->exec("CREATE TABLE IF NOT EXISTS live_lineup(product_id BIGINT UNSIGNED PRIMARY KEY,position INT NOT NULL DEFAULT 0,added_at BIGINT NOT NULL,FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$db->exec("CREATE TABLE IF NOT EXISTS orders(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,order_ref VARCHAR(80) NOT NULL UNIQUE,created_at BIGINT NOT NULL,expires_at BIGINT NOT NULL,total DECIMAL(12,2) NOT NULL,status VARCHAR(40) NOT NULL DEFAULT 'pending',items_json LONGTEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$orderFields=['paid_at'=>'BIGINT NULL','payment_mail_state'=>"VARCHAR(16) NOT NULL DEFAULT 'pending'",'payment_mail_attempted_at'=>'BIGINT NULL','payment_mail_sent_at'=>'BIGINT NULL','payment_mail_attempt_token'=>'CHAR(32) NULL','customer_email'=>'VARCHAR(190) NULL','shipping_price'=>'DECIMAL(12,2) NULL','packing_at'=>'BIGINT NULL','shipping_carrier'=>'VARCHAR(80) NULL','tracking_number'=>'VARCHAR(120) NULL','shipped_at'=>'BIGINT NULL','shipment_mail_state'=>"VARCHAR(16) NOT NULL DEFAULT 'pending'",'shipment_mail_attempted_at'=>'BIGINT NULL','shipment_mail_sent_at'=>'BIGINT NULL','shipment_mail_attempt_token'=>'CHAR(32) NULL'];
foreach($orderFields as $field=>$definition){if(!$db->query("SHOW COLUMNS FROM orders LIKE '".$field."'")->fetch()){try{$db->exec("ALTER TABLE orders ADD COLUMN `".$field."` ".$definition);}catch(PDOException $e){if((int)($e->errorInfo[1]??0)!==1060)throw $e;}}}
$db->exec("CREATE TABLE IF NOT EXISTS settings(`key` VARCHAR(150) PRIMARY KEY,`value` TEXT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$db->exec("CREATE TABLE IF NOT EXISTS promotions(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,title VARCHAR(200) NOT NULL,percent DECIMAL(5,2) NOT NULL,scope VARCHAR(40) NOT NULL,target_id BIGINT NULL,starts_at BIGINT NOT NULL,ends_at BIGINT NOT NULL,enabled TINYINT NOT NULL DEFAULT 1) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$db->exec("CREATE TABLE IF NOT EXISTS admin_audit(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,created_at BIGINT NOT NULL,event VARCHAR(75) NOT NULL,result VARCHAR(20) NOT NULL,detail VARCHAR(170) NOT NULL DEFAULT '',INDEX(created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$db->exec("CREATE TABLE IF NOT EXISTS vouchers(id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,code VARCHAR(60) NOT NULL UNIQUE,percent DECIMAL(5,2) NOT NULL,scope VARCHAR(40) NOT NULL,target_id BIGINT NULL,ends_at BIGINT NOT NULL,uses_left INT NOT NULL DEFAULT 1,enabled TINYINT NOT NULL DEFAULT 1,created_at BIGINT NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$voucherFields=['title'=>"VARCHAR(120) NOT NULL DEFAULT ''",'dedication'=>"VARCHAR(240) NOT NULL DEFAULT ''"];
foreach($voucherFields as $field=>$definition){if(!$db->query("SHOW COLUMNS FROM vouchers LIKE '".$field."'")->fetch()){$db->exec("ALTER TABLE vouchers ADD COLUMN `".$field."` ".$definition);}}
} catch (Throwable $e) {
    error_log('[HAH database schema] '.$e->getMessage());
    http_response_code(503);
    exit('Sklep: nie mozna przygotowac tabel MySQL. Sprawdz uprawnienia CREATE/ALTER i install-check.php.');
}
try {
foreach(['Wszystkie','Bluzki i koszule','Sukienki','Spodnie','Kurtki i płaszcze','Swetry','Akcesoria','Odzież damska','Odzież męska','T-shirty i topy','Bluzy','Jeansy','Spódnice','Komplety','Obuwie','Torebki','Biżuteria','Dodatki','Nowości','Wyprzedaż'] as $i=>$name){$q=$db->prepare('INSERT IGNORE INTO categories(name,sort) VALUES(?,?)');$q->execute([$name,$i]);}
} catch (Throwable $e) {
    error_log('[HAH categories] '.$e->getMessage());
    http_response_code(503);
    exit('Sklep: problem podczas dodawania kategorii. Sprawdz MySQL i log PHP.');
}
function promotionPercent(int $id,int $category):float { $q=db()->prepare("SELECT MAX(percent) FROM promotions WHERE enabled=1 AND starts_at<=? AND ends_at>? AND (scope='shop' OR (scope='category' AND target_id=?) OR (scope='product' AND target_id=?))");$q->execute([time(),time(),$category,$id]);return (float)$q->fetchColumn(); }
function priceFor(array $p):float{return round((float)$p['price']*(1-promotionPercent((int)$p['id'],(int)$p['category_id'])/100),2);}
function getVoucher(string $code):?array {if(!preg_match('/^[A-Z0-9-]{4,32}$/',$code))return null;$q=db()->prepare('SELECT * FROM vouchers WHERE code=? AND enabled=1 AND uses_left>0 AND ends_at>?');$q->execute([$code,time()]);return $q->fetch()?:null;}
function voucherApplies(array $v,array $p):bool{return $v['scope']==='shop'||($v['scope']==='category'&&(int)$v['target_id']===(int)$p['category_id'])||($v['scope']==='product'&&(int)$v['target_id']===(int)$p['id']);}
function itemPrice(array $p,?array $voucher=null):array{$base=(float)$p['price'];$promo=promotionPercent((int)$p['id'],(int)$p['category_id']);$price=round($base*(1-$promo/100),2);$codeSaving=0.0;if($voucher&&voucherApplies($voucher,$p)){$codeSaving=round($price*(float)$voucher['percent']/100,2);$price=round($price-$codeSaving,2);}return ['price'=>$price,'original_price'=>$promo>0?$base:($p['original_price']??null),'promo_percent'=>$promo,'code_saving'=>$codeSaving];}
function val(string $k,mixed $default=null):mixed {global $db; $q=$db->prepare('SELECT `value` FROM settings WHERE `key`=?');$q->execute([$k]);$v=$q->fetchColumn();return $v===false?$default:$v;}
function setval(string $k,string $v):void{global $db;$q=$db->prepare('INSERT INTO settings(`key`,`value`) VALUES(?,?) ON DUPLICATE KEY UPDATE `value`=VALUES(`value`)');$q->execute([$k,$v]);}
function jsonout(array $a,int $status=200):never{http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode($a,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function csrf():string{if(empty($_SESSION['csrf']))$_SESSION['csrf']=bin2hex(random_bytes(24));return $_SESSION['csrf'];}
function checkcsrf():void{if(!hash_equals(csrf(),(string)($_POST['csrf']??$_SERVER['HTTP_X_CSRF_TOKEN']??'')))jsonout(['error'=>'Nieprawidłowa sesja. Odśwież stronę.'],403);}
function cleanup():void{db()->prepare('DELETE FROM reservations WHERE expires_at<=?')->execute([time()]);}
function catalog():array{cleanup();$rows=db()->query('SELECT p.id,p.category_id,p.name,p.description,p.price,p.original_price,p.size,p.condition,p.stock,p.active,p.created_at,p.images_json,p.featured,p.material,p.video_url,c.name AS category,(p.stock-COALESCE((SELECT SUM(r.qty) FROM reservations r WHERE r.product_id=p.id AND r.expires_at>'.time().'),0)) AS available FROM products p JOIN categories c ON c.id=p.category_id WHERE p.active=1 ORDER BY p.created_at DESC')->fetchAll();foreach($rows as &$p){$pricing=itemPrice($p);$p['price']=$pricing['price'];$p['original_price']=$pricing['original_price'];$p['promo_percent']=$pricing['promo_percent'];$p['live_reservable']=hahProductOnLive((int)$p['id']);}unset($p);return $rows;}
function shopConfigured():bool{global $config;return filter_var($config['shop_email']??'',FILTER_VALIDATE_EMAIL)&&!str_contains($config['shop_email'],'example.com')&&filter_var($config['from_email']??'',FILTER_VALIDATE_EMAIL)&&!str_contains($config['from_email'],'example.com')&&preg_match('/^[0-9 ]{26,32}$/',preg_replace('/^PL/','',(string)($config['bank_account']??'')))&&($config['recipient']??'')!=='WPISZ NAZWE ODBIORCY';}
function settingsPublic():array{global $config;return ['shopName'=>$config['shop_name'],'shippingPrice'=>(float)val('shipping_price',(string)$config['shipping_price']),'reservationHours'=>(int)$config['reservation_hours'],'facebook'=>'https://www.facebook.com/kolohahoutlet','liveUrl'=>val('live_url',''),'liveActive'=>val('live_active','0')==='1'];}
function clienttoken():string{if(empty($_SESSION['buyer_token']))$_SESSION['buyer_token']=bin2hex(random_bytes(20));return $_SESSION['buyer_token'];}
function clearExpiredOrders():void{db()->prepare("UPDATE orders SET status='expired' WHERE status='pending' AND expires_at<=?")->execute([time()]);}

function hahLiveNow():bool {return val('live_active','0')==='1';}
function hahProductOnLive(int $id):bool {
 if(!hahLiveNow())return false;
 $q=db()->prepare('SELECT 1 FROM live_lineup WHERE product_id=?');$q->execute([$id]);return (bool)$q->fetchColumn();
}
