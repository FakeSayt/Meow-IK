<?php
declare(strict_types=1);
require_once __DIR__.'/mail_templates.php';
function hahSendPayment(array $order,?string $recipient=null):string{
 global $db,$config;$attempt=bin2hex(random_bytes(16));
 $db->beginTransaction();
 try{
  $q=$db->prepare('SELECT * FROM orders WHERE order_ref=? FOR UPDATE');$q->execute([$order['order_ref']]);$order=$q->fetch();
  if(!$order||!in_array($order['status'],['paid','packing','shipped'],true))throw new RuntimeException('Najpierw potwierdź wpłatę.');
  if($order['payment_mail_state']==='sent'){$db->commit();return 'Potwierdzenie zostało już przekazane do poczty.';}
  if($order['payment_mail_state']==='sending'){$db->commit();return 'Trwa wysyłka albo jej wynik jest niepewny. Sprawdź pocztę hostingu przed dalszym działaniem.';}
  $email=$recipient??($order['customer_email']??'');
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($email)>190){
   $db->commit();
   if($recipient!==null)throw new RuntimeException('Podaj poprawny e-mail odbiorcy.');
   return 'Wpłata potwierdzona. Uzupełnij e-mail w zamówieniu, aby wysłać potwierdzenie klientowi.';
  }
  $q=$db->prepare("UPDATE orders SET customer_email=?,payment_mail_state='sending',payment_mail_attempted_at=?,payment_mail_attempt_token=? WHERE order_ref=? AND payment_mail_state IN ('pending','failed')");
  $q->execute([$email,time(),$attempt,$order['order_ref']]);
  if($q->rowCount()!==1){$db->commit();return 'Sprawdź status potwierdzenia wpłaty w tabeli zamówień.';}
  $order['customer_email']=$email;$db->commit();
 }catch(Throwable $e){if($db->inTransaction())$db->rollBack();throw $e;}
 $plain='Potwierdzenie wpłaty za zamówienie '.$order['order_ref']."\nPotwierdzona kwota: ".number_format((float)$order['total'],2,',',' ')." zł\nPrzygotujemy Twoje zakupy do wysyłki. Po nadaniu otrzymasz numer przesyłki.\nWiadomość nie stanowi dokumentu fiskalnego.\nSklep: ".hahShopUrl()."\nKontakt: ".$config['shop_email'];
 try{$ok=hahSendMail($order['customer_email'],'Potwierdzenie wpłaty — '.$order['order_ref'],hahPaymentMailHtml($order,$config),$plain);}catch(Throwable $e){error_log('[HAH payment] '.get_class($e));$ok=false;}
 $q=$db->prepare("UPDATE orders SET payment_mail_state=?,payment_mail_sent_at=? WHERE order_ref=? AND payment_mail_state='sending' AND payment_mail_attempt_token=?");
 $q->execute([$ok?'sent':'failed',$ok?time():null,$order['order_ref'],$attempt]);
 if($q->rowCount()!==1)return 'Wpłata potwierdzona. Stan wiadomości zmienił się w innej sesji; sprawdź tabelę zamówień.';
 return $ok?'Wpłata potwierdzona. Potwierdzenie przekazano do poczty klienta.':'Wpłata potwierdzona, ale hosting odrzucił e-mail. Możesz ponowić samo potwierdzenie wpłaty.';
}
function hahRetryPayment(array $post):string{
 $email=array_key_exists('customer_email',$post)?trim((string)$post['customer_email']):null;
 return hahSendPayment(['order_ref'=>(string)($post['ref']??'')],$email);
}
function hahPaymentActions(array $order):string{
 if(!in_array($order['status'],['paid','packing','shipped'],true))return '';
 $state=$order['payment_mail_state']??'pending';
 $html='<div class="payment-mail-info"><strong>Potwierdzenie wpłaty</strong><br>';
 if($state==='sent')return $html.'E-mail przekazany do poczty.</div>';
 if($state==='sending')return $html.((int)$order['payment_mail_attempted_at']>=time()-300?'Trwa wysyłanie e-maila.':'Wynik wysyłki jest niepewny. Sprawdź pocztę hostingu; wiadomość nie zostanie ponowiona automatycznie.').'</div>';
 $html.=$state==='failed'?'Wysyłka nie powiodła się.':'E-mail nie został jeszcze wysłany.';
 return $html.'<form method="post" class="shipment-form"><input type="hidden" name="csrf" value="'.hahMailEscape(csrf()).'"><input type="hidden" name="ref" value="'.hahMailEscape($order['order_ref']).'"><input type="hidden" name="action" value="order_payment_retry"><label>E-mail odbiorcy<input type="email" name="customer_email" maxlength="190" value="'.hahMailEscape($order['customer_email']??'').'" required></label><button class="btn small">Wyślij potwierdzenie wpłaty</button></form></div>';
}
